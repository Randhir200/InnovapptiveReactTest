import React from 'react';
import Headertab from './Components/Headertab';
import Aside from './Components/Aside';
export default function App() {
  return (
    <div>
      <Headertab />
      <Aside />
    </div>
  );
}
